﻿=== Medium ===
Contributors: majelbstoat
Tags:  medium, medium auto publish, publish post to medium, medium publishing, post to medium, social media auto publish, social media publishing, social network auto publish, social media, social network
Requires at least: 3.3
Tested up to: 4.3
Stable tag: 1.0
License: Apache

Publish posts automatically to a Medium profile.

== Description ==

Medium lets you publish posts automatically to a Medium profile.

= About =

Medium is developed and maintained by [Medium](http://medium.com/ "medium.com"). For support, contact us at [yourfriends@medium.com](mailto://yourfriends@medium.com).

== Installation ==

1. Extract `medium-crosspost.zip` to your `/wp-content/plugins/` directory.
2. In the admin panel under plugins activate Medium Crosspost.
3. Add your Integration Token on the plugin settings page.
4. Were you expecting more steps? Sorry to disappoint!

== Changelog ==

= Medium Crosspost 1.0 =
* Initial release!

= Requirements =

* WordPress 3.3+
* PHP 5+
